import torch
import torch.nn as nn
import torch.nn.functional as F
from torch_geometric.nn import SAGEConv, TopKPooling

class mymodel(nn.Module):
    def __init__(self, encodeDim, decodeDim, aggregator, normalize, topkratio, nodeNum, causal_edges, cndm_data):
        """
        Graph neural network model with causal sampling and contrastive learning
        
        Args:
            encodeDim: Dimension of input node features
            decodeDim: Dimension of output node embeddings
            aggregator: Aggregation method for SAGEConv
            normalize: Whether to normalize node features
            topkratio: Ratio for TopKPooling
            nodeNum: Number of nodes in graph
            causal_edges: Dictionary of causal edges for sampling
            cndm_data: Gene-cell matrix data (genes x cells)
        """
        super(mymodel, self).__init__()
        self.decodeDim = decodeDim
        self.cnnChannel = topkratio + 2 if topkratio >= 1 else int(topkratio * nodeNum + 2)
        self.topkratio = topkratio
        self.nodeNum = nodeNum
        
        # Graph encoding layers
        self.encode = SAGEConv(encodeDim, decodeDim, aggregator, normalize)
        self.topkpool = TopKPooling(decodeDim, topkratio)
        
        # Causal data components
        self.causal_edges = causal_edges
        self.cndm = nn.Parameter(torch.tensor(cndm_data, dtype=torch.float32), requires_grad=False)
        self.temperature = 0.1  # Temperature parameter for contrastive loss
        
        # CNN layers with varying kernel sizes
        self.cnn1 = nn.Conv1d(self.cnnChannel, self.cnnChannel, kernel_size=3, stride=1, padding=1)
        self.cnn2 = nn.Conv1d(self.cnnChannel, self.cnnChannel, kernel_size=5, stride=1, padding=2)
        self.cnn3 = nn.Conv1d(self.cnnChannel, self.cnnChannel, kernel_size=7, stride=1, padding=3)
        
        # Depthwise separable convolution
        self.depthwise_conv = nn.Conv1d(self.cnnChannel, self.cnnChannel, 
                                      kernel_size=3, stride=1, padding=1,
                                      groups=self.cnnChannel)
        self.pointwise_conv = nn.Conv1d(self.cnnChannel, self.cnnChannel, 
                                       kernel_size=1, stride=1, padding=0)
        
        # Batch normalization layers
        self.bn1 = nn.BatchNorm1d(self.cnnChannel)
        self.bn2 = nn.BatchNorm1d(self.cnnChannel)
        self.bn3 = nn.BatchNorm1d(self.cnnChannel)
        self.bn4 = nn.BatchNorm1d(128)
        
        # Pooling layers
        self.pool1 = nn.MaxPool1d(2)
        self.pool2 = nn.MaxPool1d(2)
        self.pool3 = nn.MaxPool1d(2)
        
        # Fully connected layers
        self.fc0 = nn.LazyLinear(256)
        self.fc1 = nn.LazyLinear(128)
        self.fc2 = nn.Linear(128, 1)
        self.fc_fusion = nn.Parameter(torch.ones(2))  # Learnable fusion weights
        
        # Activation function
        self.sigmoid = nn.Sigmoid()

    def TopkPooling(self, x, edge_index):
        """Apply TopK pooling to graph"""
        x, _, edge_index, _, _, _ = self.topkpool(x, edge_index)
        return x

    def causal_sample(self, node, edge_index, causal_adj_list):
        """
        Sample neighbors based on causal edges
        
        Args:
            node: Current node index
            edge_index: Full graph edge index
            causal_adj_list: Dictionary of causal edges
            
        Returns:
            Tensor of sampled neighbor indices
        """
        if node in causal_adj_list:
            # Sample from causal neighbors if available
            causal_neighbors = causal_adj_list[node]
            sampled_neighbors = torch.tensor(causal_neighbors, dtype=torch.long).to(edge_index.device)
        else:
            # Otherwise sample from all neighbors
            node_neighbors = edge_index[1, edge_index[0] == node]
            sampled_neighbors = node_neighbors.clone().detach().to(torch.long).to(edge_index.device)
        return sampled_neighbors

    def contrastive_loss(self, local_features, global_features, fusion_weight):
        """
        Compute contrastive loss between local and global features
        
        Args:
            local_features: Node-level features
            global_features: Graph-level features
            fusion_weight: Learnable weights for feature fusion
            
        Returns:
            Contrastive loss value
        """
        weighted_local = fusion_weight[0] * local_features
        weighted_global = fusion_weight[1] * global_features
        
        scores = F.cosine_similarity(weighted_local.unsqueeze(1), 
                                    weighted_global.unsqueeze(0), dim=-1)
        scores = scores / self.temperature
        
        labels = torch.arange(local_features.size(0)).to(local_features.device)
        return F.cross_entropy(scores, labels)

    def Sage_forword(self, x, edge_index):
        """
        Forward pass with causal sampling and feature fusion
        
        Args:
            x: Node features
            edge_index: Graph edge indices
            
        Returns:
            Tuple of (fused features, pooled features, contrastive loss)
        """
        causal_adj_list = self.causal_edges
        
        # Perform causal sampling for each node
        sampled_neighbors_list = []
        for node in range(self.nodeNum):
            sampled_neighbors = self.causal_sample(node, edge_index, causal_adj_list)
            sampled_neighbors_list.append(sampled_neighbors)
        
        # Convert sampled neighbors to edge index format
        sampled_sources = []
        sampled_targets = []
        for i, neighbors in enumerate(sampled_neighbors_list):
            sampled_sources.extend([i] * len(neighbors))
            sampled_targets.extend(neighbors)
        sampled_edge_index = torch.tensor([sampled_sources, sampled_targets], 
                                        dtype=torch.long).to(edge_index.device)
        
        # Graph convolution with sampled edges
        x = self.encode(x, sampled_edge_index)
        x = F.relu(x)
        
        # Process CNDM data
        cndm_reshaped = self.cndm
        cndm_reshaped = self.fc0(cndm_reshaped)
        
        # Feature fusion
        fusion_weight = torch.softmax(self.fc_fusion, dim=0)
        fusion_x = fusion_weight[0] * x + fusion_weight[1] * cndm_reshaped
        
        # Contrastive loss
        loss = self.contrastive_loss(x, cndm_reshaped, fusion_weight)
        
        # TopK pooling
        topkarr = self.topkpool(fusion_x, edge_index)[0]
        return fusion_x, topkarr, loss

    def creatDecodeInput(self, x, topkarr, trainEdge):
        """
        Create decoder input by combining node features and pooled features
        
        Args:
            x: Node features
            topkarr: Pooled features
            trainEdge: Training edges
            
        Returns:
            Stacked feature tensor
        """
        stackList = []
        c = topkarr
        for i in range(trainEdge.shape[0]):
            a = x[int(trainEdge[i][0])].view(1, self.decodeDim)
            b = x[int(trainEdge[i][1])].view(1, self.decodeDim)
            hrt = torch.cat([a, b, c], 0)
            stackList.append(hrt)
        return torch.stack(stackList, 0)

    def calmodel(self, x):
        """
        CNN-based decoder network
        
        Args:
            x: Input features
            
        Returns:
            Prediction scores
        """
        # First CNN block
        x = self.bn1(x)
        x = F.relu(self.cnn1(x))
        x = self.pool1(x)
        x1 = x
        
        # Second CNN block
        x = self.bn2(x)
        x = F.relu(self.cnn2(x))
        x = self.pool2(x)
        x2 = x
        
        # Third CNN block
        x = self.bn3(x)
        x = F.relu(self.cnn3(x))
        x = self.pool3(x)
        x3 = x
        
        # Depthwise separable convolution
        x4 = F.relu(self.depthwise_conv(x))
        x4 = F.relu(self.pointwise_conv(x4))
        
        # Feature concatenation
        x = torch.cat([x1, x2, x3, x4], 2)
        x = x.view(-1, x.size()[1] * x.size()[2])
        
        # Dropout and FC layers
        x = F.dropout(x, training=self.training, p=0.5)
        x = self.fc1(x)
        x = self.bn4(x)
        x = F.relu(x)
        x = self.fc2(x)
        
        return self.sigmoid(x).view(-1)

    def score(self, x, topkarr, trainEdge):
        """Compute scores for input edges"""
        x = self.creatDecodeInput(x, topkarr, trainEdge)
        return self.calmodel(x)

    def predict(self, x):
        """Make predictions from decoder input"""
        return self.calmodel(x).cpu().data.numpy()