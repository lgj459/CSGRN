
clc
clear
data=xlsread('ExpressionData.csv');


c=[];
alpha=0.5;
boxsize=1.5;
kk=1;
weighted=1;
cndm = condition_ndm(data,alpha,boxsize,kk);
csvwrite('cndm.csv',cndm)
