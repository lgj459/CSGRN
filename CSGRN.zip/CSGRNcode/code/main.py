import torch
import torch.nn.functional as F
import pandas as pd
import numpy as np
from torch_geometric.data import Data
import argparse
import os
from model import mymodel
from Load_data import gen_split
from sklearn.metrics import precision_recall_curve, roc_curve, auc
from torch.optim.lr_scheduler import StepLR
import matplotlib.pyplot as plt

# Set random seeds for reproducibility
np.set_printoptions(threshold=np.inf)
torch.set_printoptions(profile="full")
seed = 6
torch.manual_seed(seed)
torch.cuda.manual_seed(seed)
torch.cuda.manual_seed_all(seed)  
np.random.seed(seed)
torch.backends.cudnn.benchmark = False
torch.backends.cudnn.deterministic = True

def parse_args():
    """Parse command line arguments for model configuration"""
    parser = argparse.ArgumentParser(description="Model parameter selection")
    
    # Dataset parameters
    parser.add_argument('--geneDataName', help='Gene expression data file name', 
                       type=str, default='ExpressionData.csv')
    parser.add_argument('--refNetworkName', help='Reference network file name', 
                       type=str, default='refNetwork.csv')
    parser.add_argument('--datasetPath', help='Output folder for dataset splits', 
                       type=str, default='dataset')
    parser.add_argument('--k', help='Number of folds for cross-validation', 
                       type=int, default=5)
    
    # Model training parameters
    parser.add_argument('--batchSize', help="Training batch size", 
                       type=int, default=40960)
    parser.add_argument('--decodeDim', help="Decoder output dimension", 
                       type=int, default=256)
    parser.add_argument('--aggregator', help="Graph aggregator function", 
                       choices=['mean', 'lstm', 'max'], default='mean')
    parser.add_argument('--normalize', help="Whether to normalize encoder output", 
                       type=bool, default=True)
    parser.add_argument('--topkratio', help="Top-k pooling ratio", 
                       type=int, default=1)
    parser.add_argument('--causal_edges', help="Causal edges data file", 
                       type=str, default='edges1.csv')
    parser.add_argument('--cndm_data', help="CNDM data file", 
                       type=str, default='cndm.csv')
    
    return parser.parse_args()

def main(dataPath, args):
    """Main training and evaluation function"""
    os.chdir(dataPath)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    
    # Load and prepare data
    geneExpData = pd.read_csv(args.geneDataName, sep=',', header=0, index_col=0)
    x = torch.from_numpy(np.array(geneExpData, dtype=np.float64)).float()
    cndm_data = pd.read_csv(args.cndm_data, header=None)
    cndm_data_numpy = cndm_data.to_numpy()
    
    # Initialize result containers
    all_scores = []
    all_true_edges = []
    all_tfs = []
    all_targets = []
    
    # Build reverse causal adjacency list
    causal_edges_df = pd.read_csv(args.causal_edges)
    reverse_causal_adj_list = {}
    for _, row in causal_edges_df.iterrows():
        source = int(row['source'])
        target = int(row['target'])
        if target not in reverse_causal_adj_list:
            reverse_causal_adj_list[target] = []
        reverse_causal_adj_list[target].append(source)

    # K-fold cross validation
    for i in range(args.k):
        trueEdge, trainEdge, testEdge = gen_train_test_dataset(i, args.k, args.datasetPath + '/k-fold/')
        data = Data(x=x, edge_index=trueEdge).to(device)
        trainEdge = trainEdge.to(device)
        
        # Initialize model
        model = mymodel(
            encodeDim=data.x.size()[1], 
            decodeDim=256, 
            aggregator='mean', 
            normalize=True,
            topkratio=1, 
            nodeNum=data.x.size()[0], 
            causal_edges=reverse_causal_adj_list,
            cndm_data=cndm_data_numpy
        ).to(device)
        
        optimizer = torch.optim.Adam(params=model.parameters(), lr=0.005)
        scheduler = StepLR(optimizer, step_size=5, gamma=0.8)

        # Training loop
        for epoch in range(0, 100):
            loss = train(data, model, optimizer, scheduler, trainEdge)
            print(f'Epoch: {epoch:03d}, Loss: {loss:.4f}')
        
        # Evaluation
        score = predict(model, data, testEdge[:, 0:2], args.batchSize)
        trueLabels = np.array(testEdge[:, 2])
        all_tfs.extend(testEdge[:, 0].tolist())
        all_targets.extend(testEdge[:, 1].tolist())
        all_scores.extend(score)
        all_true_edges.extend(trueLabels)

    # Save all predictions
    results_df = pd.DataFrame({
        'TF': all_tfs,
        'Target': all_targets,
        'Score': all_scores,
        'TrueLabel': all_true_edges
    })
    results_df.to_csv('all_folds_predictions.csv', index=False)

    # Calculate final metrics
    auroc, auprc = comp_res(np.array(all_scores), np.array(all_true_edges))
    print(f"Overall AUROC: {auroc}, AUPRC: {auprc}")

    return auroc, auprc

def gen_train_test_dataset(i, k, path):
    """Generate train/test splits for k-fold cross validation"""
    train_df = pd.DataFrame(columns=['TF', 'Target', 'Label'])
    test_df = pd.read_csv(path + str(i) + '.csv', sep=',', header=0, index_col=0)
    
    # Combine all other folds for training
    dataframes = [train_df]
    for j in range(k):
        if j == i:
            continue
        temp_df = pd.read_csv(path + str(j) + '.csv', sep=',', header=0, index_col=0)
        dataframes.append(temp_df)
    train_df = pd.concat(dataframes, ignore_index=True)

    # Prepare edge tensors
    trueEdge = pd.DataFrame(train_df.loc[train_df['Label'] == 1, ['TF', 'Target']], dtype='int64')
    trueEdge = torch.from_numpy(np.array(trueEdge).T).long()
    trainEdge = torch.from_numpy(np.array(train_df.sample(frac=1), dtype='int64'))
    testEdge = torch.from_numpy(np.array(test_df.sample(frac=1), dtype='int64'))
    
    return trueEdge, trainEdge, testEdge

def train(data, model, optimizer, scheduler, trainEdge):
    """Model training function"""
    model.train()
    optimizer.zero_grad()
    
    # Forward pass
    x, topkarr, loss2 = model.Sage_forword(data.x, data.edge_index)
    linkPredict = model.score(x, topkarr, trainEdge)
    linkLabels = trainEdge[:, 2].float()
    
    # Loss calculation
    loss1 = F.binary_cross_entropy_with_logits(linkPredict, linkLabels)
    loss = loss1 * 0.9 + loss2 * 0.1
    
    # Backward pass
    loss.backward()
    optimizer.step()
    scheduler.step()
    
    return loss

@torch.no_grad()
def predict(model, data, testEdge, batchSize):
    """Batch prediction function"""
    model.eval()
    inputx, topkarr, _ = model.Sage_forword(data.x, data.edge_index)

    Score = np.empty(shape=0)
    stack_list = []
    times = 1
    
    # Process in batches
    for i in range(testEdge.shape[0]):
        a = inputx[int(testEdge[i][0])].view(1, model.decodeDim)
        b = inputx[int(testEdge[i][1])].view(1, model.decodeDim)
        hrt = torch.cat([a, b, topkarr], 0)
        stack_list.append(hrt)
        
        if times % batchSize == 0:
            x = torch.stack(stack_list, 0)
            batchScore = model.predict(x)
            Score = np.hstack((Score, batchScore))
            stack_list.clear()
        times += 1
    
    # Process remaining samples
    if stack_list:
        x = torch.stack(stack_list, 0)
        batchScore = model.predict(x)
        Score = np.hstack((Score, batchScore))
        stack_list.clear()
    
    return Score.reshape(Score.shape[0], 1)

def comp_res(score, trueEdge):
    """Compute evaluation metrics (AUROC and AUPRC)"""
    reslist = []
    for i in range(trueEdge.size):
        reslist.append([score[i], trueEdge[i]])
    
    resDF = pd.DataFrame(reslist, columns=['pre', 'true'])
    
    # Calculate AUROC
    fpr, tpr, _ = roc_curve(resDF['true'], resDF['pre'], pos_label=1)
    auroc = auc(fpr, tpr)
    
    # Calculate AUPRC
    precision, recall, _ = precision_recall_curve(resDF['true'], resDF['pre'])
    auprc = auc(recall, precision)
    
    return auroc, auprc

if __name__ == '__main__':
    args = parse_args()
    path = 'F:/flowsig-main/IGEGRNS-main/论文/data'
    datafile = 'example'
    dataPath = path + '/' + datafile + '/'

    # Initialize results dataframe
    resDF = pd.DataFrame(columns=['AUROC', 'AUPRC', 'Density'])
    resDF.to_csv(dataPath + 'result.csv', index=True, sep=',')
    
    # Process all datasets
    for files in os.listdir(dataPath):
        os.chdir(dataPath)
        if files == 'result.csv':
            continue
            
        for file in os.listdir(files):
            print(file+'_'+files)
            tempDataPath = dataPath + files + '/' + file + '/'
            density = gen_split(tempDataPath, args)
            AUROC, AUPRC = main(tempDataPath, args)
            
            # Save results
            resDF = pd.read_csv(dataPath+'result.csv', sep=',', index_col=0)
            resDF.loc[file+'_'+files] = [AUROC, AUPRC, density]
            resDF.to_csv(dataPath+'result.csv', index=True, sep=',')