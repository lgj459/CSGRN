"""
-*- coding: utf-8 -*-
@Author : Smartpig
@Institution : DHU/DBLab
@Time : 2022/3/27 16:45
"""

import pandas as pd
import os

def gen_geneNameDict(datasetPath, geneExpData, refNetwork):
    """
    Generate gene dictionaries for TFs and Targets, and create edge list from reference network
    
    Args:
        datasetPath: Path to save output files
        geneExpData: Gene expression data
        refNetwork: Reference network data
    
    Returns:
        DataFrames for TFs, Targets, and Edges
    """
    # Create gene name dictionary mapping names to indices
    geneName = pd.DataFrame({'geneName': geneExpData,
                           'index': range(geneExpData.shape[0])})
    geneName.to_csv(datasetPath + 'geneNameDict.csv', index=True, sep=',')
    geneNameDict = dict(zip(geneName['geneName'], geneName['index']))
    
    # Get unique TFs and Targets
    tf = refNetwork['Gene1'].drop_duplicates()
    target = refNetwork['Gene2'].drop_duplicates()
    
    # Create TF dictionary with indices
    tfDic = [[tf.iloc[i], geneNameDict[tf.iloc[i]]] for i in range(tf.shape[0])]
    TF = pd.DataFrame(tfDic, columns=['TF', 'index'])
    
    # Create Target dictionary with indices
    targetDic = [[target.iloc[i], geneNameDict[target.iloc[i]]] for i in range(target.shape[0])]
    Target = pd.DataFrame(targetDic, columns=['Target', 'index'])
    
    # Create edge list with indices
    edgeDic = [[geneNameDict[refNetwork.iloc[i, 0]], geneNameDict[refNetwork.iloc[i, 1]]] 
              for i in range(refNetwork.shape[0])]
    Edge = pd.DataFrame(edgeDic, columns=['TF', 'Target'])
    
    # Save outputs
    TF.to_csv(datasetPath + 'TF.csv', index=True, sep=',')  # TF names with expression matrix indices
    Target.to_csv(datasetPath + 'Target.csv', index=True, sep=',')  # Target names with indices
    Edge.to_csv(datasetPath + 'Edge.csv', index=True, sep=',')  # TF-Target pairs with indices
    
    return TF, Target, Edge

def gen_dataSplit(datasetPath, TF, Target, Edge, k):
    """
    Generate positive and negative samples for k-fold cross validation
    
    Args:
        datasetPath: Path to save output files
        TF: DataFrame of transcription factors
        Target: DataFrame of target genes  
        Edge: DataFrame of known edges
        k: Number of folds for cross-validation
    
    Returns:
        Density of positive edges
    """
    # Generate positive and negative edges
    posEdge = []
    negEdge = []
    
    for i in range(TF.shape[0]):
        tf_idx = TF.iloc[i, 1]  # Current TF index
        for j in range(Target.shape[0]):
            target_idx = Target.iloc[j, 1]  # Current Target index
            # Check if edge exists in reference network
            if not Edge.loc[(Edge['TF'] == tf_idx) & (Edge['Target'] == target_idx)].empty:
                posEdge.append([tf_idx, target_idx, 1])  # Positive sample
            else:
                negEdge.append([tf_idx, target_idx, 0])  # Negative sample
    
    # Shuffle and create DataFrames
    posEdge = pd.DataFrame(posEdge, columns=['TF', 'Target', 'Label']).sample(frac=1)
    negEdge = pd.DataFrame(negEdge, columns=['TF', 'Target', 'Label']).sample(frac=1)
    posEdgeNum, negEdgeNum = posEdge.shape[0], negEdge.shape[0]
    
    # Create k-fold splits
    os.chdir(datasetPath)
    splitPath = 'k-fold'
    if not os.path.exists(splitPath):
        os.mkdir(splitPath)
    splitPath = datasetPath + splitPath + '/'
    
    for i in range(k):
        # Create fold by combining positive and negative samples
        split_df = pd.concat([
            posEdge.iloc[int(posEdgeNum*(i/k)):int(posEdgeNum*((i+1)/k))],
            negEdge.iloc[int(negEdgeNum*(i/k)):int(negEdgeNum*((i+1)/k))]
        ], ignore_index=True)
        split_df.to_csv(splitPath + str(i) + '.csv', index=True, sep=',')
    
    return posEdgeNum / (posEdgeNum + negEdgeNum)  # Positive edge density

def gen_split(dataPath, args):
    """
    Main function to generate all data splits
    
    Args:
        dataPath: Base working directory
        args: Command line arguments containing:
            - datasetPath: Output directory name
            - geneDataName: Gene expression filename
            - refNetworkName: Reference network filename
            - k: Number of folds
    
    Returns:
        Edge density
    """
    os.chdir(dataPath)
    # Create output directory
    datasetPath = args.datasetPath
    if not os.path.exists(datasetPath):
        os.mkdir(datasetPath)
    datasetPath = dataPath + datasetPath + '/'
    
    # Load input data
    geneExpData = pd.read_csv(args.geneDataName, sep=',', header=0, index_col=None)
    refNetwork = pd.read_csv(args.refNetworkName, sep=',', header=0, index_col=None)
    
    # Generate dictionaries and splits
    TF, Target, Edge = gen_geneNameDict(datasetPath, geneExpData.iloc[:, 0], refNetwork.iloc[:, 0:2])
    density = gen_dataSplit(datasetPath, TF, Target, Edge, args.k)
    
    return density