from causaldag import unknown_target_igsp, gsp
from causaldag import partial_correlation_suffstat, partial_correlation_test, MemoizedCI_Tester
import pandas as pd
import networkx as nx

# Load and prepare data
data = pd.read_csv('ExpressionData.csv', index_col=0).T
nodes = list(data.columns)

# Run GSP using partial correlation
obs_suffstat = partial_correlation_suffstat(data, invert=True)
ci_tester = MemoizedCI_Tester(partial_correlation_test, obs_suffstat, alpha=1e-3)

# Estimate DAG structure
est_dag = gsp(nodes, ci_tester, nruns=20)

# Create directed graph and extract edges
G = nx.DiGraph()
edges_list = []
for arc in est_dag.arcs:
    start_gene, end_gene = nodes[arc[0]], nodes[arc[1]]
    G.add_edge(start_gene, end_gene)
    edges_list.append([start_gene, end_gene])

# Save edges to CSV
pd.DataFrame(edges_list, columns=['Gene1', 'Gene2']).to_csv('edges.csv', index=False)

# Map gene names to indices and save indexed edges
geneExpData = pd.read_csv('ExpressionData.csv', index_col=0)
gene2idx = {gene: idx for idx, gene in enumerate(geneExpData.index)}

edge_index = []
for _, row in pd.read_csv('edges.csv').iterrows():
    source_idx = gene2idx.get(row['Gene1'])
    target_idx = gene2idx.get(row['Gene2'])
    if source_idx is not None and target_idx is not None:
        edge_index.append([source_idx, target_idx])

pd.DataFrame(edge_index, columns=['source', 'target']).to_csv('edges1.csv', index=False)

print('Processing completed')